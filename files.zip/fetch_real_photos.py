"""
Give every non-Ticketmaster event in events.csv ONE plain, related photo from Openverse.
No text, no overlay, no cropping tricks: just the photo, saved as a PNG (photos/event_NNN.png).

Photo source: Openverse (https://openverse.org), the Creative Commons image search run by
WordPress. No account or API key needed for light use. Only photos licensed for commercial
use are requested. Creator/license info goes in photo_credits.csv (not on the images).

Usage (needs internet; run from the folder that has events.csv and photos/):
    pip install pillow
    python fetch_real_photos.py

How it works
- Rows whose Link points to ticketmaster.com are left alone (pull_ticketmaster.py handles those).
- Every other row's title is mapped to a short search term ("half marathon", "yoga garden").
  Each distinct term is searched ONCE and every event with that term gets a different result,
  so similar events don't all get the identical photo (~50 requests total).
- The photo is saved as a PNG (converted to RGB, shrunk only if wider/taller than 1600 px).
  The Photos column is updated, and any old flyer (.svg) or earlier text-overlay (.jpg) file
  for that event is deleted.
- Timeouts (HTTP 504 etc.) are retried with backoff and simpler fallback searches. If Openverse
  keeps failing, or rate-limits you (HTTP 429), progress is saved and the script stops.
  Run it again later: rows that already have a .png are skipped.
- Optional higher limits: register a free Openverse API client
  (https://api.openverse.org/v1/#tag/auth) and set OPENVERSE_CLIENT_ID and
  OPENVERSE_CLIENT_SECRET before running.
"""
import csv, io, json, os, re, sys, time
import urllib.error, urllib.parse, urllib.request
from PIL import Image

API = "https://api.openverse.org/v1"
UA = {"User-Agent": "sunhacks-demo/1.0 (student hackathon project)"}
PAUSE = 3.5  # seconds between API calls (stays under 20/min)
MAX_SIDE = 1600

# ---------- title -> short search term ----------
TERMS = [
    (r"Hackathon", "hackathon"),
    (r"Hack Night", "hackathon students laptops"),
    (r"for Beginners Workshop", "coding workshop laptop"),
    (r"Robotics", "robotics club"),
    (r"3D Printing", "3d printer"),
    (r"Solar Car", "solar car"),
    (r"Career Fair", "career fair"),
    (r"Resume Review", "resume review"),
    (r"Networking Mixer", "networking event"),
    (r"Career Panel", "panel discussion"),
    (r"Startup Pitch", "startup pitch"),
    (r"Founders", "coffee meeting"),
    (r"Fun Run", "fun run race"),
    (r"Half Marathon", "half marathon"),
    (r"Sunrise Run", "group run sunrise"),
    (r"Social Cycling", "group bike ride"),
    (r"Bike Maintenance", "bicycle repair"),
    (r"Gravel", "gravel bike"),
    (r"Intramural (.+?) Sign", r"\1 game"),
    (r"Pickleball", "pickleball"),
    (r"Football Tailgate", "college football tailgate"),
    (r"Student Night: Suns", "basketball arena crowd"),
    (r"Open Mic", "open mic night"),
    (r"Campus Concert", "live concert band"),
    (r"Gallery Walk", "art gallery visitors"),
    (r"(Watercolor|Pottery|Screen Printing|Digital Illustration|Linocut) Night", r"\1 class"),
    (r"Meditation", "meditation sunrise"),
    (r"Worship", "worship music"),
    (r"Sunday Student Service", "brunch table"),
    (r"Interfaith", "community dinner"),
    (r"Book Club", "book club"),
    (r"Poetry Slam", "poetry reading"),
    (r"Author Talk", "author book signing"),
    (r"Free Food Friday: Boba", "boba tea"),
    (r"Free Food Friday: (\w+)", r"\1 food"),
    (r"Study Break", "snacks coffee library"),
    (r"Finals Study", "students studying library"),
    (r"Research Symposium", "research poster presentation"),
    (r"Science Cafe: (.+)", r"\1"),
    (r"Women in STEM", "women scientists"),
    (r"Silent Disco", "silent disco"),
    (r"Friendsgiving", "thanksgiving dinner friends"),
    (r"Winter Formal", "formal dance"),
    (r"Guided Hike", "desert hiking Arizona"),
    (r"Night Hike", "stargazing desert"),
    (r"Yoga", "yoga garden"),
    (r"Mental Health", "wellness fair"),
    (r"Esports", "esports tournament"),
    (r"Board Game", "board games"),
    (r"Film Screening", "film screening"),
    (r"Improv", "improv comedy"),
    (r"Musical Auditions", "theater audition"),
    (r"Volunteer Day: Food Bank", "food bank volunteers"),
    (r"Volunteer Day: .*Cleanup", "river cleanup volunteers"),
    (r"Volunteer Day: .*Toy", "toy drive"),
    (r"Volunteer Day: .*Garden", "community garden volunteers"),
    (r"Lunar New Year", "lunar new year festival"),
    (r"Native American Heritage", "native american dance"),
    (r"Hanukkah", "hanukkah menorah"),
    (r"Dia de los Muertos", "dia de los muertos"),
    (r"Black History Month", "black history month celebration"),
    (r"International Student Potluck", "potluck dinner"),
    (r"Language Exchange", "language exchange cafe"),
]

def term_for(row):
    for pat, term in TERMS:
        m = re.search(pat, row["Title"])
        if m:
            return m.expand(term).lower() if "\\" in term else term
    cat = next((c.strip() for c in row["Category"].split(";") if c.strip() != "Free Food"), "students")
    return f"{cat} students"

# ---------- Openverse ----------
class RateLimited(Exception):
    pass

_token = None
def auth_headers():
    global _token
    cid, secret = os.environ.get("OPENVERSE_CLIENT_ID"), os.environ.get("OPENVERSE_CLIENT_SECRET")
    h = dict(UA)
    if cid and secret:
        if _token is None:
            data = urllib.parse.urlencode({"grant_type": "client_credentials",
                                           "client_id": cid, "client_secret": secret}).encode()
            with urllib.request.urlopen(urllib.request.Request(f"{API}/auth_tokens/token/", data=data, headers=UA), timeout=20) as r:
                _token = json.load(r)["access_token"]
        h["Authorization"] = f"Bearer {_token}"
    return h

class Transient(Exception):
    """Server timeout / overload (HTTP 500, 502, 503, 504) or network timeout after retries."""

def http_get(url, headers=None, retries=3, timeout=60):
    delay = 5
    for attempt in range(retries + 1):
        try:
            req = urllib.request.Request(url, headers=headers or UA)
            with urllib.request.urlopen(req, timeout=timeout) as r:
                return r.read()
        except urllib.error.HTTPError as e:
            if e.code == 429:
                raise RateLimited()
            if e.code not in (500, 502, 503, 504):
                raise
            err = f"HTTP {e.code}"
        except (urllib.error.URLError, TimeoutError, ConnectionError) as e:
            err = f"network error: {e}"
        if attempt == retries:
            raise Transient(err)
        print(f"   {err} - retrying in {delay}s ...")
        time.sleep(delay)
        delay *= 3

# Openverse can be slow or time out on filtered searches, so if one attempt fails we fall
# back to simpler/cheaper versions of the same search before giving up on a term.
def search(term):
    param_sets = [
        {"q": term, "page_size": 20, "category": "photograph", "license_type": "commercial", "aspect_ratio": "wide", "mature": "false"},
        {"q": term, "page_size": 20, "category": "photograph", "license_type": "commercial", "mature": "false"},
        {"q": term, "page_size": 10, "license_type": "commercial", "mature": "false"},
    ]
    last_err = None
    for params in param_sets:
        time.sleep(PAUSE)
        try:
            results = json.loads(http_get(f"{API}/images/?" + urllib.parse.urlencode(params),
                                          auth_headers(), retries=1)).get("results", [])
        except Transient as e:
            last_err = e
            continue
        if results:
            return results
    if last_err:
        raise last_err
    return []

def download(hit):
    for u in (hit.get("url"), hit.get("thumbnail")):
        if not u:
            continue
        try:
            return Image.open(io.BytesIO(http_get(u, retries=1)))
        except RateLimited:
            raise
        except Exception:
            continue
    raise RuntimeError("no downloadable image")

# ---------- main ----------
CREDIT_HEADER = ["file", "title", "creator", "license", "source_page", "attribution"]

def save_all(rows, cols, credits):
    with open("events.csv", "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=cols); w.writeheader(); w.writerows(rows)
    with open("photo_credits.csv", "w", newline="", encoding="utf-8") as f:
        csv.writer(f).writerows([CREDIT_HEADER] + credits)

def is_ticketmaster(row):
    return "ticketmaster.com" in row["Link"].lower()

def main():
    rows = list(csv.DictReader(open("events.csv", encoding="utf-8")))
    cols = list(rows[0].keys())
    credits = []
    if os.path.exists("photo_credits.csv"):
        credits = [r for r in csv.reader(open("photo_credits.csv", encoding="utf-8"))][1:]
    cache, used, failed_terms = {}, {}, {}
    fail_streak = 0
    try:
        for row in rows:
            if is_ticketmaster(row) or row["Photos"].lower().endswith(".png"):
                continue
            num = re.search(r"event_(\d+)", row["Photos"]).group(1)
            old = row["Photos"]
            term = term_for(row)
            try:
                if term in failed_terms:
                    print("skipped (search failed earlier this run):", row["Title"]); continue
                if term not in cache:
                    cache[term] = search(term)
                    fail_streak = 0
                results = cache[term]
                if not results:
                    print("no photo found:", row["Title"], f"(searched '{term}')"); continue
                k = used.get(term, 0); used[term] = k + 1
                hit = results[k % len(results)]
                img = download(hit).convert("RGB")
                img.thumbnail((MAX_SIDE, MAX_SIDE))
                fn = f"photos/event_{num}.png"
                img.save(fn, "PNG")
                row["Photos"] = fn
                if old != fn and os.path.exists(old):
                    os.remove(old)
                credits = [c for c in credits if c and c[0] not in (old, fn)]
                credits.append([fn, row["Title"], hit.get("creator") or "unknown",
                                f'{hit.get("license", "")} {hit.get("license_version", "")}'.strip(),
                                hit.get("foreign_landing_url", ""), hit.get("attribution", "")])
                print("ok", fn, "-", row["Title"], f"[{term}]")
            except RateLimited:
                raise
            except Transient as e:
                failed_terms[term] = str(e)
                fail_streak += 1
                print(f"search for '{term}' failed ({e}):", row["Title"])
                if fail_streak >= 4:
                    print("\nOpenverse keeps timing out right now. Progress saved - try again in a while.")
                    break
            except Exception as e:
                print("failed:", row["Title"], "-", e)
    except RateLimited:
        print("\nOpenverse rate limit reached. Progress saved; wait a bit and run again to continue.")
    finally:
        save_all(rows, cols, credits)

if __name__ == "__main__":
    main()
