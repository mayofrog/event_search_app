"""
Replace 30% of the rows in events.csv with REAL Phoenix-area events from the Ticketmaster
Discovery API: real event links, real venue addresses, and the event's own Ticketmaster image.

Setup (free): create an account at https://developer.ticketmaster.com, copy your Consumer Key.
    pip install pillow
    set TICKETMASTER_API_KEY=your_key        (Windows)  |  export TICKETMASTER_API_KEY=your_key
Run from the folder that has events.csv and photos/:
    python pull_ticketmaster.py

What it does
- Searches within 40 miles of downtown Phoenix, Nov 16 2026 - Feb 20 2027, across Music, Sports,
  Arts & Theatre and Miscellaneous; keeps only events whose venue is in Arizona; de-duplicates by name.
- Picks 30 of them (a mix of segments) and overwrites 30 existing rows (random rows that are not
  already Ticketmaster events), so you end up with 30 Ticketmaster + 70 other events.
  Run it before or after fetch_real_photos.py; fetch_real_photos.py skips Ticketmaster rows.
- Column mapping: Title=name, Datetime=local start, Location=venue + street address,
  Description=event info (or a short generated line), Link=the real ticketmaster.com event page,
  Attendees=blank (the API doesn't provide it), Category=mapped to your 20 categories,
  Photos=the event's Ticketmaster image saved to photos/event_NNN.jpg, Fee=price range
  (or TBD if none listed), Host=promoter (or venue when no promoter is listed).
- Re-sorts the CSV by Datetime and removes the replaced rows' old photos / credit lines.
Free tier: 5,000 calls/day, 5 calls/second. This script uses ~10 API calls.
"""
import csv, io, json, os, random, re, sys, time
import urllib.error, urllib.parse, urllib.request
from PIL import Image

API = "https://app.ticketmaster.com/discovery/v2/events.json"
UA = {"User-Agent": "sunhacks-demo/1.0"}
LATLONG, RADIUS = "33.4484,-112.0740", 40          # downtown Phoenix, miles
START, END = "2026-11-16T00:00:00Z", "2027-02-20T23:59:59Z"
N_REPLACE = 30
TARGET_MIX = {"Music": 12, "Sports": 8, "Arts & Theatre": 7, "Miscellaneous": 3}

# ---------- API ----------
def api_events(params):
    url = API + "?" + urllib.parse.urlencode(params)
    time.sleep(0.3)  # stay under 5 requests/second
    with urllib.request.urlopen(urllib.request.Request(url, headers=UA), timeout=30) as r:
        data = json.load(r)
    return data.get("_embedded", {}).get("events", [])

def fetch_candidates(key):
    out = []
    for segment in TARGET_MIX:
        for page in (0, 1):
            evs = api_events({"apikey": key, "latlong": LATLONG, "radius": RADIUS, "unit": "miles",
                              "countryCode": "US", "classificationName": segment,
                              "startDateTime": START, "endDateTime": END,
                              "size": 100, "page": page, "sort": "date,asc"})
            out += evs
            if len(evs) < 100:
                break
    return out

def download_image(url):
    with urllib.request.urlopen(urllib.request.Request(url, headers=UA), timeout=30) as r:
        return Image.open(io.BytesIO(r.read()))

# ---------- mapping ----------
def venue_of(ev):
    vs = ev.get("_embedded", {}).get("venues", [])
    return vs[0] if vs else None

def in_arizona(ev):
    v = venue_of(ev)
    return bool(v and v.get("state", {}).get("stateCode") == "AZ" and v.get("name"))

def usable(ev):
    s = ev.get("dates", {}).get("start", {})
    return bool(s.get("localDate") and s.get("localTime") and not s.get("dateTBA") and not s.get("noSpecificTime")
                and ev.get("url") and ev.get("name") and in_arizona(ev))

def classification(ev):
    cl = (ev.get("classifications") or [{}])[0]
    return (cl.get("segment", {}).get("name") or "", cl.get("genre", {}).get("name") or "",
            cl.get("subGenre", {}).get("name") or "")

def map_categories(ev):
    seg, genre, _ = classification(ev)
    name = ev["name"].lower()
    cats = []
    if seg == "Music":
        cats.append("Music & Concerts")
        if genre in ("Dance/Electronic", "Hip-Hop/Rap", "Latin"):
            cats.append("Parties & Nightlife")
    elif seg == "Sports":
        cats.append("Sports")
        if "marathon" in name or "5k" in name or " run" in name:
            cats.append("Running")
        if "cycl" in name or "bike" in name:
            cats.append("Cycling")
    elif seg == "Arts & Theatre":
        cats.append("Art & Design" if genre == "Fine Art" else "Film & Theater")
        if genre in ("Classical", "Opera") or "symphony" in name:
            cats.append("Music & Concerts")
    elif seg == "Film":
        cats.append("Film & Theater")
    else:
        cats.append("Cultural & Diversity")
        if genre in ("Fairs & Festivals", "Community/Civic"):
            cats.append("Parties & Nightlife")
    if any(w in name for w in ("esports", "gaming", "comic con", "comiccon", "anime")):
        cats.append("Gaming & Esports")
    return list(dict.fromkeys(cats))

def location(ev):
    v = venue_of(ev)
    street = (v.get("address") or {}).get("line1", "")
    city = (v.get("city") or {}).get("name", "")
    zipc = v.get("postalCode", "")
    parts = [v["name"], street, city, f"AZ {zipc}".strip()]
    return ", ".join(p for p in parts if p)

def description(ev):
    text = (ev.get("info") or ev.get("pleaseNote") or "").strip()
    text = re.sub(r"\s+", " ", text)
    if text:
        sentences = re.split(r"(?<=[.!?])\s+", text)
        return " ".join(sentences[:2])[:300]
    seg, genre, _ = classification(ev)
    kind = f"{seg} ({genre})" if genre and genre != "Undefined" else (seg or "Live")
    return f"{ev['name']} - {kind.lower()} event at {venue_of(ev)['name']}. Tickets available through Ticketmaster."

def fee(ev):
    pr = ev.get("priceRanges")
    if not pr:
        return "TBD"
    lo, hi = pr[0].get("min"), pr[0].get("max")
    if lo is None:
        return "TBD"
    fmt = lambda x: f"${x:,.0f}" if float(x).is_integer() else f"${x:,.2f}"
    return fmt(lo) if hi in (None, lo) else f"{fmt(lo)}-{fmt(hi)}"

def host(ev):
    prom = (ev.get("promoter") or (ev.get("promoters") or [{}])[0] or {}).get("name")
    return prom or venue_of(ev)["name"]

def best_image(ev):
    imgs = [i for i in ev.get("images", []) if i.get("ratio") == "16_9" and not i.get("fallback")] or ev.get("images", [])
    big = sorted((i for i in imgs if i.get("width", 0) >= 800), key=lambda i: i["width"])
    return (big[0] if big else sorted(imgs, key=lambda i: i.get("width", 0))[-1])["url"] if imgs else None

def to_row(ev, num, photo_path):
    s = ev["dates"]["start"]
    return {
        "Title": ev["name"],
        "Datetime": f'{s["localDate"]} {s["localTime"][:5]}',
        "Location": location(ev),
        "Description": description(ev),
        "Link": ev["url"],
        "Attendees": "",
        "Category": "; ".join(map_categories(ev)),
        "Photos": photo_path,
        "Fee": fee(ev),
        "Host": host(ev),
    }

# ---------- selection ----------
def choose(events, n, rng):
    seen, by_seg = set(), {}
    for ev in events:
        if not usable(ev) or ev["name"].lower() in seen or not best_image(ev):
            continue
        seen.add(ev["name"].lower())
        by_seg.setdefault(classification(ev)[0] or "Miscellaneous", []).append(ev)
    for lst in by_seg.values():
        rng.shuffle(lst)
    picked = []
    for seg, want in TARGET_MIX.items():
        picked += by_seg.get(seg, [])[:want]
    rest = [e for lst in by_seg.values() for e in lst if e not in picked]
    rng.shuffle(rest)
    picked += rest[: max(0, n - len(picked))]
    return picked[:n]

def main():
    key = os.environ.get("TICKETMASTER_API_KEY")
    if not key:
        sys.exit("Set TICKETMASTER_API_KEY first (free key at https://developer.ticketmaster.com).")
    rows = list(csv.DictReader(open("events.csv", encoding="utf-8")))
    cols = list(rows[0].keys())
    num_of = lambda r: int(re.search(r"event_(\d+)", r["Photos"]).group(1))
    replaceable = [r for r in rows if "ticketmaster.com" not in r["Link"].lower()]

    events = choose(fetch_candidates(key), N_REPLACE, random.Random(31))
    if not events:
        sys.exit("No usable Ticketmaster events came back. Check your key / date range.")
    targets = random.Random(32).sample(replaceable, min(len(events), len(replaceable)))

    replaced_files, replaced_old = [], []
    for row, ev in zip(targets, events):
        num = num_of(row)
        fn = f"photos/event_{num:03d}.jpg"
        try:
            download_image(best_image(ev)).convert("RGB").save(fn, quality=90)
        except Exception as e:
            print("image failed, skipping:", ev["name"], "-", e); continue
        old = row["Photos"]
        replaced_old.append(old)
        new = to_row(ev, num, fn)
        row.clear(); row.update(new)
        if old != fn and os.path.exists(old):
            os.remove(old)
        replaced_files.append(fn)
        print("ok", fn, "-", new["Title"], "|", new["Datetime"], "|", new["Location"])

    rows.sort(key=lambda r: r["Datetime"])
    with open("events.csv", "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=cols); w.writeheader(); w.writerows(rows)
    if os.path.exists("photo_credits.csv") and replaced_files:      # drop credit lines for replaced photos
        lines = list(csv.reader(open("photo_credits.csv", encoding="utf-8")))
        with open("photo_credits.csv", "w", newline="", encoding="utf-8") as f:
            csv.writer(f).writerows([l for l in lines if not l or l[0] not in set(replaced_files) | set(replaced_old)])
    print(f"\nReplaced {len(replaced_files)} rows with real Ticketmaster events.")

if __name__ == "__main__":
    main()
